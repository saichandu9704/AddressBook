void populateAddressbook(Addressbook *addressbook);
